package com.yusaksatria.miniproject2

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper


class DatabaseOpenHelper(context: Context?) :
    SQLiteOpenHelper(context, DATABASE, null, VERSION) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE memo(date INTEGER PRIMARY KEY, memo TEXT);")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}

    companion object {
        const val DATABASE = "memos.db"
        const val TABLE = "memo"
        const val VERSION = 1
    }
}