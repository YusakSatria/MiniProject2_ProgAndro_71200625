package com.yusaksatria.miniproject2

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import java.util.*


class DatabaseAcces private constructor(context: Context) {
    private var database: SQLiteDatabase? = null
    private val openHelper: DatabaseOpenHelper
    fun open() {
        database = openHelper.getWritableDatabase()
    }

    fun close() {
        if (database != null) {
            database!!.close()
        }
    }

    fun save(memo: Memo) {
        val values = ContentValues()
        values.put("date", memo.getTime())
        values.put("memo", memo.getText())
        database!!.insert(DatabaseOpenHelper.TABLE, null, values)
    }

    fun update(memo: Memo) {
        val values = ContentValues()
        values.put("date", Date().time)
        values.put("memo", memo.getText())
        val date = java.lang.Long.toString(memo.getTime())
        database!!.update(DatabaseOpenHelper.TABLE, values, "date = ?", arrayOf(date))
    }

    fun delete(memo: Memo) {
        val date = java.lang.Long.toString(memo.getTime())
        database!!.delete(DatabaseOpenHelper.TABLE, "date = ?", arrayOf(date))
    }

    val allMemos: List<*>
        get() {
            val memos: MutableList<*> = ArrayList<Any>()
            val cursor = database!!.rawQuery("SELECT * From memo ORDER BY date DESC", null)
            cursor.moveToFirst()
            while (!cursor.isAfterLast) {
                val time = cursor.getLong(0)
                val text = cursor.getString(1)
                memos.add(Memo(time, text))
                cursor.moveToNext()
            }
            cursor.close()
            return memos
        }

    companion object {
        @Volatile
        private var instance: DatabaseAcces? = null
        @Synchronized
        fun getInstance(context: Context): DatabaseAcces? {
            if (instance == null) {
                instance = DatabaseAcces(context)
            }
            return instance
        }
    }

    init {
        openHelper = DatabaseOpenHelper(context)
    }
}
