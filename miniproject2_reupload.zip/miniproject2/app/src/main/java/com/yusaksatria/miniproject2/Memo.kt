package com.yusaksatria.miniproject2

import java.io.Serializable
import java.text.DateFormat
import java.text.SimpleDateFormat
import java.util.*


class Memo : Serializable {
    private var date: Date
    var text: String? = null
    var isFullDisplayed = false

    constructor() {
        date = Date()
    }

    constructor(time: Long, text: String?) {
        date = Date(time)
        this.text = text
    }

    fun getDate(): String {
        return dateFormat.format(date)
    }

    var time: Long
        get() = date.time
        set(time) {
            date = Date(time)
        }
    val shortText: String
        get() {
            val temp = text!!.replace("/n".toRegex(), " ")
            return if (temp.length > 25) {
                temp.substring(0, 25) + "..."
            } else {
                temp
            }
        }

    override fun toString(): String {
        return text!!
    }

    companion object {
        private val dateFormat: DateFormat = SimpleDateFormat("dd/MM/yyy 'at' hh:mm aaa")
    }
}